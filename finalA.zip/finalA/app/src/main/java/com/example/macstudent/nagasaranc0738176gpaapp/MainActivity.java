package com.example.macstudent.nagasaranc0738176gpaapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button addbutton;
    private  Button searchbutton;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


       addbutton = findViewById(R.id.addbutton);
       searchbutton  = findViewById(R.id.searchbutton);



    }
}
