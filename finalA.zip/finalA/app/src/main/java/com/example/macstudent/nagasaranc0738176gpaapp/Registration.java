package com.example.macstudent.nagasaranc0738176gpaapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;

public class Registration extends AppCompatActivity {

    EditText FirstName;
    EditText LastName;
    EditText Email;
    EditText Mobile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        FirstName = findViewById(R.id.FirstName);
        LastName  = findViewById(R.id.LastName);
        Email = findViewById(R.id.Email);
        Mobile = findViewById(R.id.Mobile);
    }
}
